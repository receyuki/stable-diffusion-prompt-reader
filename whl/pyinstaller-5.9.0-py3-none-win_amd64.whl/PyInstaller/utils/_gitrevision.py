#
# The content of this file will be filled in with meaningful data when creating an archive using `git archive` or by
# downloading an archive from github, e.g., from github.com/.../archive/develop.zip
#
rev = "77022483b4"  # abbreviated commit hash
commit = "77022483b440448c62efd264ab5c5d5dd26b2e03"  # commit hash
date = "2023-03-13 20:38:36 +0000"  # commit date
author = "Brénainn Woodsend <bwoodsend@gmail.com>"
ref_names = "tag: v5.9.0"  # incl. current branch
commit_message = """Release v5.9.0. [skip ci]
"""
